public class Assign4
{
	
	public static void main(String args[])
	{
		float time=16.17f;
		
		if(time>5.00f && time<12.00f){
			System.out.println("Good Morning..");
		}
		
		else{
			System.out.println("It's not morning time..");
		}
		
	}
	
}

/*
C:\Users\Lenovo\OneDrive\Desktop\JAVA\JavaAssignments>javac Assign4.java

C:\Users\Lenovo\OneDrive\Desktop\JAVA\JavaAssignments>java Assign4
It's not morning time..

*/